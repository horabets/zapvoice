import './static/js/chunk-b7c20765.js';
