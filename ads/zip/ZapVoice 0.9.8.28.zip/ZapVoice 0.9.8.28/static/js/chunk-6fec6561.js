setTimeout(()=>{window.location.href="https://web.whatsapp.com/\u{1F310}/pt_br"},100);
